
[{TableOfContents }]()

### Microsoft Windows Issues

#### Wiki configuration
The least painful approach to defining the location of your Wiki files is to have them located at the same drive as your Tomcat (or other web server) installation, and define the location in Unix format. For example, files in C:\Wikantik\files are defined in the configuration file as /Wikantik/files.
Also make sure you change the setting for `appender.rolling.fileName` in `wikantik.properties` if you want a logfile to be created. This setting is in the Log4j 2.x configuration section near the end of the config-file. The format is the same as the `jspwiki.fileSystemProvider.pageDir`-setting, i.e. backslashes must be duplicated.

### UTF-8 Issues

If you are having problems with Tomcat 5.x (or higher) and Wikantik with UTF-8, please note the following!

You have to edit the server.xml of Tomcat (located in the conf-directory of Tomcat). Please add to

``<Connector port="8080"
               maxThreads="150" minSpareThreads="25" maxSpareThreads="75"
               enableLookups="false" redirectPort="8443" acceptCount="100"
               debug="0" connectionTimeout="20000" 
               disableUploadTimeout="true"/>``

the term '``URIEncoding="UTF-8"``'.

It should look like this:

``
<Connector port="8080"
               maxThreads="150" minSpareThreads="25" maxSpareThreads="75"
               enableLookups="false" redirectPort="8443" acceptCount="100"
               debug="0" connectionTimeout="20000" 
               disableUploadTimeout="true" 
               URIEncoding="UTF-8"/>
``

Remember that if you use mod_jk, you should define the `URIEncoding` for the JK Connector too :

``
.........
  <service name="Catalina">
    <connector port="8080" />
.........
    <connector protocol="AJP/1.3" uriencoding="UTF-8" port="8009" />
.........
  </service>
``

### Other tips

#### Editing the menu on the left hand side.

The menu on the left hand side (over there <-----) is just a standard Wiki page, called [LeftMenu]().

If you (the administrator) don't want anyone else to modify it, you can always edit [LeftMenu](), and then make the page read-only by putting an ACL on it.

The lower part of the left hand side is similarly called [LeftMenuFooter](), and it is fully editable as well.

#### Enabling the [RSS](http://blogspace.com/rss/) feed

In your wikantik.properties -file, you'll need to set the "wikantik.rss.generate" to "true".

#### I don't like~ ThingsSquashedTogether in the page titles. What can I do?

As Finns say, "voe tokkiinsa", meaning "yes, of course". Just set the "wikantik.breakTitleWithSpaces" property to "true" in your wikantik.properties-file.
