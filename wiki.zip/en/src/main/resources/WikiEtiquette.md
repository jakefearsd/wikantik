
When [editing pages](TextFormattingRules) just keep the following rules in mind:

### General

* Be nice - don't be rude or offensive.
* Write in a way that is easy to understand and avoid local slang or phrases. Many of those who will read your text may not have English as their first language.
* Don't delete other people's contributions (unless you know what you are doing)
* Don't use too many acronyms (or at least, have a page explaining them)
* **Avoid the _"click here"_ phrase!!** Don't say: "More info about etiquette can be found [here](WikiEtiquette)" but use "More info about etiquette can be found at [WikiEtiquette]()". I'd suggest avoiding it for external links as well.
* Contribute only original stuff. Links are fine, but don't cut-and-paste from copyrighted things.
* Correcting typos is quite okay - in fact, it's a very good habit, since it makes the web page more readable.

### About comments

* You are free to contribute anonymously, but it is preferred that you sign your comments with your name (or handle). It is common to prepend the signature with '--' like this: _-- [Janne Jalkanen]()_ (While you're at it, you are free to create your own wikipage and tell us about yourself.)
* A good way is also to put your name first, like this: _[Janne Jalkanen]() : I'd like to say that..._
* Think before you comment. [WikiWiki]() is not a high-speed conversation board. It's not a news server either. What you say will stay here forever (if you delete your comment, it is still in the previous version of the page) for everyone to see and comment.

### Creating [WikiNames](WikiName)

* A good [WikiName]() is short and descriptive. If the name is logical and easy many more people will link to it.
* Although you can take a whole sentence and crunch it up to make a [WikiName](), it is better style to restrain it to at most 5 words.
* Instead, try to use [WikiName]()s like you would use as chapter titles in a book.
* This Wiki allows you to create pages with a single word as a name, but try to use at least two words - we don't want to exhaust the name space :-).
* **Double-check [WikiName]()s for typos** - otherwise someone will create a misnamed page! Misnamed pages are bad, since linking to them requires more effort than to a logical, correct [WikiName]().

### Refactoring pages

Refactoring is the process where you sum up a page, shortening it, making it more accessible. Anyone who feels up to it may go ahead, but we suggest that youleave it up to frequent (experienced) visitors.

* Be objective - both pros and cons have to be represented correctly.
* Be careful with signed contributions - don't change their meaning.
* Give credit where credit is due.
* Use 3rd person or plural instead 1st person singular in your summary.

(Thanks to [Sensei's library](http://senseis.xmp.net/) for this initial text.)
