
[WikiNames](WikiName) are traditionally written using~ InterCapping, also known as~ CamelCase (starting with uppercase letter, and at least another uppercase letter in the wiki link word). This makes the creation of internal hyperlinks really easy.

However, in this [WikiWiki]() the [links]() are written using the [[link] notation, as the original~ InterCapping style of linking is occasionally confusing. The names still conform to the [WikiWiki]() standard, if you look at the URL at the top.

Names are _crushed_, i.e. [[This is a link] becomes [[ThisIsALink]. However, underscores and dots are retained, so you can have a link like this: [[This_is_a_link], or [[This.Is.A.Link]. All non-alphanumeric characters except for '_' and '.' are removed (that is, all characters that are not letters or numbers), so that [[John's page] becomes [[JohnsPage]. This allows you to type normal sentences which are then turned into links, like when talking about [Wiki etiquette](WikiEtiquette).

A [WikiName]() can not be a number. Numeric names are used for [footnotes](TextFormattingRules).
