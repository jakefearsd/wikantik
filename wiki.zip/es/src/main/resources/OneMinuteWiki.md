
¡Hola! ¡Y bienvenido al Wiki!

[WikiWiki]() es Hawaiano y significa "rápido". La idea original de [WikiWiki]() era crear un entorno rápido, colaborativo que además fuese persistente.

Cualquiera puede contribuir, incluso anónimamente. Sí, puedes borrar lo que otras personas han dicho, e incluso puedes borrar páginas enteras, pero sorprendentemente, las wikis [funcionan](WikiWikiWeb:WhyWikiWorks).

Cuando editas, puedes crear fácilmente (y deberías crear) hiperenlaces simplemente poniendo palabras entre corchetes, [[tal que así]. Si la página a la que te refieres no existe, la página resultante mostrará el nombre subrayado con línea discontinua. Por ejemplo: [EstaPaginaNoExiste](). (Por favor no fastidies el ejemplo creando esa página...)

Los [WikiNombres]() que contengan espacios o guiones bajos son aplastados y capitalizados juntos, por lo que [[Esto es un enlace] se convierte en [[EstoEsUnEnlace].

Una wiki es y debría ser simple. Por eso no hay necesidad de HTML complejo. Puedes conseguir algunos efectos, como **texto en negrita** y _cursiva_, pero nada muy complicado. La disposición de los elementos es problema de la propia wiki. Hay más información al respecto en las [Reglas de Formato del Texto](TextFormattingRules).
