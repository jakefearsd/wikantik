
A veces es útil que el nombre de una página _realmente_ signifique otra página distinta. Por ejemplo, puede que te interese tener una página llamada "Alias dsiponibles", pero también que dicha página fuese accesible además bajo el nombre "Alias". En este caso, puedes usar un "alias de la página":

Escribe lo siguiente en la página "[PageAliases]()": (Hay una página de ejemplo ahí, por lo que si haces click en el enlace te devolveremos aquí.)

``
[{SET alias='PageAlias'}]
``

Cada vez que alguien solicite la página "[PageAliases]()", será automáticamente redirigido a esta página. Esto es bastante útil si, por ejemplo, quieres poder usar formas de plural irregulares. Normalmente, Wikantik reconoce los plurales en inglés de los nombres de las páginas, pero no es lo suficientemente listo como para reconocer determinadas formas de plural, como en el caso de "aliases".

#### Editando las páginas de alias/redirección

Bueno, obviamente no puedes hacer click en enlace de "Editar", vas a ser redirido cada vez que intentes editar la página. Sin embargo, puedes editar la página directamente escribiendo `Edit.jsp?page=_pagename_` directamente justo después de la URL base o usando una referencia interWiki para editar, por defecto esto se consigue así [[Aliases|Edit:Aliases].
