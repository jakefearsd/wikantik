
[{TableOfContents }]()

### 邮件列表
在这个 wiki 之外有个用于讨论的 Wikantik 邮件列表。很适合讨论诸如补丁、问题、开发等等的问题。
目前有两个邮件列表：_jspwiki-users_ 和 _jspwiki-dev_。

#### Wikantik-user

jspwiki-user 邮件列表由 Apache 托管。可以通过发送邮件到以下地址申请加�：[user-subscribe@wikantik.com](mailto:user-subscribe@wikantik.com)。邮件列表归档位于 [http://mail-archives.apache.org/mod_mbox/jspwiki-user/]()

[以前的列表归档](http://www.ecyrd.com/pipermail/jspwiki-users/) 还在。另外，在 Nabble 上还有一个 [副归档](http://www.nabble.com/JspWiki---User-f2680.html)。

#### Wikantik-dev

这个列表主要针对 Wikantik 开发�。如果�心满天飞的暗语的话，最好还是别加�。jspwiki-dev 列表由 Apache 托管，所以您可以通过给下面的地址发个邮件来加�：[dev-subscribe@wikantik.com](mailto:dev-subscribe@wikantik.com)。邮件列表归档位于 [http://mail-archives.apache.org/mod_mbox/jspwiki-dev/]()

#### Wikantik-commits

如果订�了这个列表，你会在向 SVN 库提交了新的或修改过的文件时会收到邮件通知。jspwiki-commits 列表由 Apache 托管，您可以通过给下面的地址发送邮件加�：[commits-subscribe@wikantik.com](mailto:commits-subscribe@wikantik.com)。邮件列表归档位于 [http://mail-archives.apache.org/mod_mbox/jspwiki-commits/]()

#### 取消订�

取消订�同样容易：您只需用订�列表时使用的邮件地址给 <user|dev|commits>-unsubscribe@wikantik.com 发送邮件即可完成。

如果您想探究一些有趣的问题的话，以前的 Wikantik-dev（到 2007年10月）归档[还可以用](http://www.ecyrd.com/pipermail/jspwiki-dev/)。

### �他资源

#### [IrcChannel]() - 与开发�在线聊天！

在 [Freenode](http://www.freenode.net) 上有个 Wikantik [IRC](http://www.mirc.com/irc.html) 频道，名称为：#jspwiki. 如果有任何疑问，或�只是想聊聊，可以进去看看。

需要注意的是，有些时段这个频道里面会相当安静，如果发了消息没有回复的话，属于正常，不要泄气。就在线等一会儿看看……

频道上的常客；

* [Janne Jalkanen](http://www.ecyrd.com/Wikantik/wiki/JanneJalkanen) (Ecyrd)：时区为 GMT+2.

#### [FaceBook](http://www.facebook.com/group.php?gid=11138025370)

另外，我还在 Facebook 上建了一个 Wikantik 用户组作为娱乐。如果您是 Facebook 上的常客，可以去看看！

（当然，我们不会用这个替换任何现有的站点。不过，每个人还有他们的亲友似乎也在 Facebook 上，我似乎觉得再加一个频道也不错）-- Janne 2007年9月17日
