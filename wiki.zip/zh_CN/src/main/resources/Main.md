
## 恭喜您！

您已经成功安�了 [Wikantik](About)。

一些页面已经为您设好了：

#### 马上开始

* 如果想体验一下，试试[沙盒](SandBox)。
* 如果想简单了解一下 Wiki 是什么，看看 [OneMinuteWiki]()。
* 如果想了解�于 Wiki 使用方面的指南的话，参� [WikiEtiquette]()。

#### 安�问题

* 如果您在使用 Microsoft Windows，或�有 UTF-8 方面的麻烦，您可以参� [InstallationTips]() 了解更多信息。

#### 文档

* 有� Wiki 标记的�部特性，请参� [TextFormattingRules]()。
* 完整 Wikantik 文档�口：[Wikantik 文档](Wikantik:WikantikDocumentation)
    * [Wikantik 新特性](Wikantik:NewIn).

#### �他

* 有好几种途径可以和 Wikantik [Community]() 联系。去看看！
* 想看看这个 wiki 是什么样的，可以点击浏览器左上角的 Wiki 名称，或�[点击此处](SystemInfo)。

祝你好运，感谢选择 Wikantik！
