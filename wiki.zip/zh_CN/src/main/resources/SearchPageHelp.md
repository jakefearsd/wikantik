
本页面简要介绍了搜索引擎查询语法。此页面名为 [Search Page Help](SearchPageHelp)。

使用 '+' 表示要求一个词，'-' 禁止一个词。例如：

``
          +java -emacs jsp
``

会查找**�须**�含单词 "java"，但可以不�含单词 "emacs"。另外，�含单词 "jsp" 的页面排在没有�含 "jsp" 的页面的前面。

所有搜索都是不区分大小写。如果一个页面同时�含禁止和需要的�键字，则它不会显示。

### 查询语法表

有�更多信息，请参� [Lucene 查询语法](http://lucene.apache.org/core/4_4_0/queryparser/org/apache/lucene/queryparser/classic/package-summary.html#package_description) {.slimbox}

| term | 查找单个词容易 | `hello`
| "..." | 查找一组单词 | `"hello dolly"`
| ? | 任意单个字符（? 不能是搜索字符串中的第一个字符） | `te?t`
| * | 任意多个字符（* 不能是搜索字符串中的第一个字符 | `test*`
| OR | 任意一个�键字存在则匹�文档 | `"hello dolly" hello`   
`"hello dolly" OR hello`
| AND | 两个�键字同时存在则匹�文档 | `"hello dolly" AND "dolly lucy"`
| + | 要求 "+" 后的�键字存在 | `+hello dolly`
| -   
NOT | 排除那些�含 "-" 号后�键字的文档   
排除也支持 NOT 或� ! | `"hello dolly" -"dolly lucy"`   
`"hello dolly" NOT "dolly lucy"`
| (...) | 用括号表示子查询 | `(hello OR dolly) AND website`
| ~~ | _模糊_搜索拼写相似的�键字 | `roam~ `
| ~n | _接近_搜索，在以单词个数表示的范围�搜素 | `"hello dolly"~10`
| ^n | _提高_因子增加搜素中的重要性 | `"hello dolly"^4 "dolly lucy"`
| \ | 转义特殊字符：** + - && ~|~| ! ( ) { } [[ ] ^ " ~ * ? : \ ** | `\(1\+1\)\:2` to find (1+1):2

可以在查询字符串前面加上前缀来限制搜索范围：

| author:_term_ | 查找由特定作�修改的页面 | `author~:JohnFoo`
| attachment:_term_ | 查找特定附件名 | `attachment:brushed*`
| name:_term_ | 查找有特定页面名称的页面 | `name:Main`
| content:_term_ | 查找有特定�容的页面 | `content:jspwiki`
{.}
